<?php
/*
Plugin Name: Bare Bones Widget
Plugin URI: http://www.cssnewbie.com/building-a-wordpress-widget/
Description: This is a very Bare Bones WordPress 2.8+ widget. Hello, World!
Author: Rob L Glazebrook
Version: 1.0
Author URI: http://www.cssnewbie.com/
*/

class WP_Widget_BareBones extends WP_Widget {

	// The widget construct. Mumbo-jumbo that loads our code.
	function WP_Widget_BareBones() {
		$widget_ops = array( 'classname' => 'widget_BareBones', 'description' => __( "A BareBones Widget" ) );
		$this->WP_Widget('bareBones', __('BareBones'), $widget_ops);
	} // End function WP_Widget_BareBones

	// This code displays the widget on the screen.
	function widget($args, $instance) {
		extract($args);
		echo $before_widget;
		if(!empty($instance['title'])) { 
			echo $before_title . $instance['title'] . $after_title; 
		}
		echo "<p>Hello world!</p>";
		echo $after_widget;
	} // End function widget.
	
	// Updates the settings.
	function update($new_instance, $old_instance) {
		return $new_instance;
	} // End function update
	
	// The admin form.
	function form($instance) {		
		echo '<div id="bareBones-admin-panel">';
		echo '<label for="' . $this->get_field_id("title") .'">BareBones Title:</label>';
		echo '<input type="text" class="widefat" ';
		echo 'name="' . $this->get_field_name("title") . '" '; 
		echo 'id="' . $this->get_field_id("title") . '" ';
		echo 'value="' . $instance["title"] . '" />';
		echo '<p>This widget will display the title you choose above followed by a "Hello World!" statement.</p>';
		echo '</div>';
	} // end function form

} // end class WP_Widget_BareBones

// Register the widget.
add_action('widgets_init', create_function('', 'return register_widget("WP_Widget_BareBones");'));
?>