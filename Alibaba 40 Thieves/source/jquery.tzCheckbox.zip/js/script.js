$(document).ready(function(){
	
	$('input[type=checkbox]').tzCheckbox({labels:['Enable','Disable']});
});